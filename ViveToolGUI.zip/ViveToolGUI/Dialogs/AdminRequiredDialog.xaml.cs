using Microsoft.UI.Xaml.Controls;

namespace ViVeToolGUI.Dialogs
{
    public sealed partial class AdminRequiredDialog : ContentDialog
    {
        public AdminRequiredDialog()
        {
            this.InitializeComponent();
        }
    }
}