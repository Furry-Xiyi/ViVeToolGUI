using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Windows.ApplicationModel.DataTransfer;
using Windows.ApplicationModel.Resources;
using Windows.Storage;
using WinRT.Interop;

namespace ViVeToolGUI
{
    public class FeatureInfo
    {
        public string Id { get; set; } = "";
        public string Priority { get; set; } = "";
        public string State { get; set; } = "";
        public string Type { get; set; } = "";
        public string Name { get; set; } = "";
    }

    public sealed partial class QueryPage : Page
    {
        private readonly ResourceLoader _resourceLoader;
        private readonly List<FeatureInfo> _allFeatures = new();
        private CancellationTokenSource _renderCancellation;
        private int _currentBatchIndex = 0;
        private const int BatchSize = 200;
        private List<FeatureInfo> _featureList;
        private bool _allLoaded = false;

        public QueryPage()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = Microsoft.UI.Xaml.Navigation.NavigationCacheMode.Enabled;
            _resourceLoader = ResourceLoader.GetForViewIndependentUse();
        }

        private async void QueryAllButton_Click(object sender, RoutedEventArgs e)
        {
            QueryAllButton.IsEnabled = false;
            ExportButton.IsEnabled = false;
            SearchBox.IsEnabled = false;

            LoadingOverlay.Visibility = Visibility.Visible;
            LoadingText.Text = "Querying features...";

            _allFeatures.Clear();
            FeaturesListView.Items.Clear();

            _renderCancellation?.Cancel();

            try
            {
                if (!await App.EnsureViVeToolInitializedAsync())
                {
                    var dialog = new Dialogs.ErrorDialog("ViVeTool is still initializing. Please wait and try again.");
                    dialog.XamlRoot = this.XamlRoot;
                    await dialog.ShowAsync();
                    return;
                }

                var result = await MainWindow.ExecuteViVeToolCommandAsync("/query");

                if (this.Frame == null || this.Frame.Content != this)
                    return;

                if (result.ExitCode == 0)
                {
                    LoadingText.Text = "Parsing results...";
                    await Task.Delay(100);

                    ParseQueryOutput(result.Output);

                    System.Diagnostics.Debug.WriteLine($"[QueryPage] Parsed {_allFeatures.Count} features");

                    LoadingText.Text = $"Loading features...";

                    _renderCancellation = new CancellationTokenSource();
                    await RenderFeaturesIncrementallyAsync(_allFeatures, _renderCancellation.Token);

                    ExportButton.IsEnabled = _allFeatures.Count > 0;
                }
                else
                {
                    var dialog = new Dialogs.ErrorDialog(result.Error);
                    dialog.XamlRoot = this.XamlRoot;
                    await dialog.ShowAsync();
                }
            }
            catch (Exception ex)
            {
                if (this.Frame == null || this.Frame.Content != this)
                    return;

                var dialog = new Dialogs.ErrorDialog(ex.Message);
                dialog.XamlRoot = this.XamlRoot;
                await dialog.ShowAsync();
            }
            finally
            {
                if (this.Frame != null && this.Frame.Content == this)
                {
                    QueryAllButton.IsEnabled = true;
                    SearchBox.IsEnabled = true;
                    LoadingOverlay.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void ParseQueryOutput(string output)
        {
            _allFeatures.Clear();

            if (string.IsNullOrWhiteSpace(output))
                return;

            output = Regex.Replace(output, @"\x1B\[[0-9;]*m", "");
            output = output.Replace("\uFEFF", "");

            var lines = Regex.Split(output, @"\r\n|\n|\r")
                             .Select(l => l.TrimEnd())
                             .Where(l => !string.IsNullOrWhiteSpace(l))
                             .ToList();

            FeatureInfo current = null;

            foreach (var line in lines)
            {
                var idMatch = Regex.Match(line, @"\[(\d+)\](?:\s*\(([^)]+)\))?");
                if (idMatch.Success)
                {
                    if (current != null)
                        _allFeatures.Add(current);

                    current = new FeatureInfo
                    {
                        Id = idMatch.Groups[1].Value,
                        Name = idMatch.Groups[2].Success ? idMatch.Groups[2].Value.Trim() : ""
                    };
                    continue;
                }

                if (current == null)
                    continue;

                if (line.Contains("Priority"))
                {
                    var m = Regex.Match(line, @"Priority\s*:\s*([A-Za-z]+)");
                    if (m.Success)
                        current.Priority = m.Groups[1].Value;
                    continue;
                }

                if (line.Contains("State"))
                {
                    var m = Regex.Match(line, @"State\s*:\s*([A-Za-z]+)");
                    if (m.Success)
                        current.State = m.Groups[1].Value;
                    continue;
                }

                if (line.Contains("Type"))
                {
                    var m = Regex.Match(line, @"Type\s*:\s*([A-Za-z]+)");
                    if (m.Success)
                        current.Type = m.Groups[1].Value;
                    continue;
                }
            }

            if (current != null)
                _allFeatures.Add(current);
        }

        private async Task RenderFeaturesIncrementallyAsync(IEnumerable<FeatureInfo> features, CancellationToken cancellationToken)
        {
            FeaturesListView.Items.Clear();
            _featureList = features.ToList();
            _currentBatchIndex = 0;
            _allLoaded = false;

            await LoadNextBatchAsync(cancellationToken);
        }

        private async Task LoadNextBatchAsync(CancellationToken cancellationToken)
        {
            if (_featureList == null) return;

            // 剩余条目数
            int remaining = _featureList.Count - _currentBatchIndex * BatchSize;
            if (remaining <= 0)
            {
                _allLoaded = true;
                LoadingText.Text = "All features loaded.";
                return;
            }

            // 只加载剩余条目，不强制 200
            var batchItems = _featureList.Skip(_currentBatchIndex * BatchSize)
                                         .Take(Math.Min(BatchSize, remaining))
                                         .ToList();

            foreach (var feature in batchItems)
            {
                if (cancellationToken.IsCancellationRequested)
                    return;

                FeaturesListView.Items.Add(CreateFeatureItem(feature)); // 动态创建控件
            }

            _currentBatchIndex++;
            LoadingText.Text = $"Loaded {FeaturesListView.Items.Count}/{_featureList.Count}";

            await Task.Delay(100, cancellationToken); // 给 UI 线程喘息机会
        }

        private void FeaturesListView_Loaded(object sender, RoutedEventArgs e)
        {
            var listView = sender as ListView;
            var scrollViewer = FindScrollViewer(listView);
            if (scrollViewer != null)
            {
                scrollViewer.ViewChanged += async (s, args) =>
                {
                    // 已全部加载则直接退出，不再触发
                    if (_allLoaded) return;

                    // 滚动到底部时加载下一批
                    if (scrollViewer.VerticalOffset >= scrollViewer.ScrollableHeight)
                    {
                        await LoadNextBatchAsync(_renderCancellation.Token);
                    }
                };
            }
        }

        private ScrollViewer FindScrollViewer(DependencyObject root)
        {
            if (root is ScrollViewer sv) return sv;

            int count = VisualTreeHelper.GetChildrenCount(root);
            for (int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(root, i);
                var result = FindScrollViewer(child);
                if (result != null) return result;
            }
            return null;
        }

        private Grid CreateFeatureItem(FeatureInfo feature)
        {
            var grid = new Grid
            {
                Padding = new Thickness(12, 6, 12, 6),
                ColumnSpacing = 12,
                Height = 32,
                Tag = feature // 🔥 存储 FeatureInfo 以便右键菜单使用
            };

            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // 🔥 创建右键菜单
            var contextMenu = new MenuFlyout();

            var enableItem = new MenuFlyoutItem
            {
                Text = "Enable Feature",
                Icon = new FontIcon { Glyph = "\uE8FB" }
            };
            enableItem.Click += async (s, e) => await EnableFeatureAsync(feature.Id);
            contextMenu.Items.Add(enableItem);

            var disableItem = new MenuFlyoutItem
            {
                Text = "Disable Feature",
                Icon = new FontIcon { Glyph = "\uE8F8" }
            };
            disableItem.Click += async (s, e) => await DisableFeatureAsync(feature.Id);
            contextMenu.Items.Add(disableItem);

            contextMenu.Items.Add(new MenuFlyoutSeparator());

            var copyIdItem = new MenuFlyoutItem
            {
                Text = "Copy Feature ID",
                Icon = new FontIcon { Glyph = "\uE8C8" }
            };
            copyIdItem.Click += (s, e) => CopyToClipboard(feature.Id);
            contextMenu.Items.Add(copyIdItem);

            grid.ContextFlyout = contextMenu;

            var idText = new TextBlock
            {
                Text = feature.Id ?? "",
                FontFamily = new FontFamily("Consolas"),
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 13
            };
            Grid.SetColumn(idText, 0);
            grid.Children.Add(idText);

            var priorityText = new TextBlock
            {
                Text = feature.Priority ?? "",
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 13
            };
            Grid.SetColumn(priorityText, 1);
            grid.Children.Add(priorityText);

            var stateText = new TextBlock
            {
                Text = feature.State ?? "",
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 13
            };
            Grid.SetColumn(stateText, 2);
            grid.Children.Add(stateText);

            var typeText = new TextBlock
            {
                Text = feature.Type ?? "",
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 13
            };
            Grid.SetColumn(typeText, 3);
            grid.Children.Add(typeText);

            var nameText = new TextBlock
            {
                Text = feature.Name ?? "",
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                FontSize = 13
            };
            Grid.SetColumn(nameText, 4);
            grid.Children.Add(nameText);

            return grid;
        }

        // 🔥 启用功能
        private async Task EnableFeatureAsync(string featureId)
        {
            try
            {
                LoadingOverlay.Visibility = Visibility.Visible;
                LoadingText.Text = $"Enabling feature {featureId}...";

                var result = await MainWindow.ExecuteViVeToolCommandAsync($"/enable /id:{featureId}");

                LoadingOverlay.Visibility = Visibility.Collapsed;

                if (result.ExitCode == 0)
                {
                    var dialog = new Dialogs.SuccessDialog($"Feature {featureId} enabled successfully!");
                    dialog.XamlRoot = this.XamlRoot;
                    await dialog.ShowAsync();

                    // 可选：重新查询以刷新状态
                    // QueryAllButton_Click(null, null);
                }
                else
                {
                    var dialog = new Dialogs.ErrorDialog($"Failed to enable feature:\n{result.Error}");
                    dialog.XamlRoot = this.XamlRoot;
                    await dialog.ShowAsync();
                }
            }
            catch (Exception ex)
            {
                LoadingOverlay.Visibility = Visibility.Collapsed;
                var dialog = new Dialogs.ErrorDialog(ex.Message);
                dialog.XamlRoot = this.XamlRoot;
                await dialog.ShowAsync();
            }
        }

        // 🔥 禁用功能
        private async Task DisableFeatureAsync(string featureId)
        {
            try
            {
                LoadingOverlay.Visibility = Visibility.Visible;
                LoadingText.Text = $"Disabling feature {featureId}...";

                var result = await MainWindow.ExecuteViVeToolCommandAsync($"/disable /id:{featureId}");

                LoadingOverlay.Visibility = Visibility.Collapsed;

                if (result.ExitCode == 0)
                {
                    var dialog = new Dialogs.SuccessDialog($"Feature {featureId} disabled successfully!");
                    dialog.XamlRoot = this.XamlRoot;
                    await dialog.ShowAsync();
                }
                else
                {
                    var dialog = new Dialogs.ErrorDialog($"Failed to disable feature:\n{result.Error}");
                    dialog.XamlRoot = this.XamlRoot;
                    await dialog.ShowAsync();
                }
            }
            catch (Exception ex)
            {
                LoadingOverlay.Visibility = Visibility.Collapsed;
                var dialog = new Dialogs.ErrorDialog(ex.Message);
                dialog.XamlRoot = this.XamlRoot;
                await dialog.ShowAsync();
            }
        }

        // 🔥 复制到剪贴板
        private void CopyToClipboard(string text)
        {
            var dataPackage = new DataPackage();
            dataPackage.SetText(text);
            Clipboard.SetContent(dataPackage);
        }

        private async void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_allFeatures.Count == 0)
                return;

            string text = SearchBox.Text?.ToLower() ?? "";

            _renderCancellation?.Cancel();
            _renderCancellation = new CancellationTokenSource();

            if (string.IsNullOrWhiteSpace(text))
            {
                await RenderFeaturesIncrementallyAsync(_allFeatures, _renderCancellation.Token);
            }
            else
            {
                var filtered = _allFeatures.Where(f =>
                    (!string.IsNullOrEmpty(f.Id) && f.Id.Contains(text, StringComparison.OrdinalIgnoreCase)) ||
                    (!string.IsNullOrEmpty(f.Name) && f.Name.Contains(text, StringComparison.OrdinalIgnoreCase)) ||
                    (!string.IsNullOrEmpty(f.State) && f.State.Contains(text, StringComparison.OrdinalIgnoreCase)) ||
                    (!string.IsNullOrEmpty(f.Priority) && f.Priority.Contains(text, StringComparison.OrdinalIgnoreCase)) ||
                    (!string.IsNullOrEmpty(f.Type) && f.Type.Contains(text, StringComparison.OrdinalIgnoreCase))
                ).ToList();

                await RenderFeaturesIncrementallyAsync(filtered, _renderCancellation.Token);
            }
        }

        private async void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ExportButton.IsEnabled = false;

                var documentsFolder = await StorageFolder.GetFolderFromPathAsync(
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));

                string baseFileName = $"ViVeTool_Query_{DateTime.Now:yyyyMMdd_HHmmss}";

                var txtFile = await documentsFolder.CreateFileAsync(
                    $"{baseFileName}.txt",
                    CreationCollisionOption.GenerateUniqueName);

                string txtContent = "";
                foreach (var f in _allFeatures)
                {
                    txtContent += $"[{f.Id}] {f.Name}\n";
                    txtContent += $"  Priority: {f.Priority}\n";
                    txtContent += $"  State: {f.State}\n";
                    txtContent += $"  Type: {f.Type}\n\n";
                }
                await FileIO.WriteTextAsync(txtFile, txtContent);

                var csvFile = await documentsFolder.CreateFileAsync(
                    $"{baseFileName}.csv",
                    CreationCollisionOption.GenerateUniqueName);

                string csvContent = "ID,Priority,State,Type,Name\n";
                foreach (var f in _allFeatures)
                {
                    csvContent += $"{f.Id},{f.Priority},{f.State},{f.Type},\"{f.Name}\"\n";
                }
                await FileIO.WriteTextAsync(csvFile, csvContent);

                var dialog = new Dialogs.SuccessDialog(
                    $"Exported successfully!\n\nTXT: {txtFile.Name}\nCSV: {csvFile.Name}",
                    documentsFolder.Path);
                dialog.XamlRoot = this.XamlRoot;
                await dialog.ShowAsync();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[ExportButton] Exception: {ex}");
                var dialog = new Dialogs.ErrorDialog($"Export failed: {ex.Message}");
                dialog.XamlRoot = this.XamlRoot;
                await dialog.ShowAsync();
            }
            finally
            {
                ExportButton.IsEnabled = true;
            }
        }
    }
}